export async function handler(_event: unknown) { // eslint-disable-line @typescript-eslint/no-unused-vars

    const mappings = {
        "ACME": "DUMMY TEXT",        
    };
    return mappings

}